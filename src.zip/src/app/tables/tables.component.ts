import { Component, OnInit } from '@angular/core';
import { ServicesService} from '../services/services.service';
import { IssueModel} from '../models/issue';
declare interface TableData {
    headerRow: string[];
    dataRows: string[][];
}

@Component({
  selector: 'app-tables',
  templateUrl: './tables.component.html',
  styleUrls: ['./tables.component.css']
})
export class TablesComponent implements OnInit {
   
    public cols: any;
    public readIssueResult: any;
    public issueEnabled: boolean= false;
    public selectedRow: any; 
    public issue: IssueModel= new IssueModel();
    constructor(private Services: ServicesService) { }

  ngOnInit() {
    this.Services.fetchIssueData().subscribe(res => {
        this.readIssueResult= res; 
        console.log(res)});
  
        this.cols = [
          { field: 'bookID', header: 'Book Id', sortable: true, filter: true, filterMatchMode: 'contains', allowToggle: true, style: { 'width': '200px', 'vertical-align': 'top' } }, 
          { field: 'bookName', header: 'Book Name', sortable: true, filter: true, filterMatchMode: 'contains', allowToggle: true, style: { 'width': '200px', 'vertical-align': 'top' } },
          { field: 'memberID', header: 'Member Id', sortable: true, filter: true, filterMatchMode: 'contains', allowToggle: true, style: { 'width': '200px', 'vertical-align': 'top' } },            
          { field: 'memberName', header: 'Member Name', sortable: true, filter: true, filterMatchMode: 'contains', allowToggle: true, style: { 'width': '200px', 'vertical-align': 'top' } } ,
          { field: 'issueDate', header: 'Issue Date', sortable: true, filter: true, filterMatchMode: 'contains', allowToggle: true, style: { 'width': '200px', 'vertical-align': 'top'} }
        ]   ;
       //this can wait 
      // if(sessionStorage.getItem('isLibrarian')== 'Y'){
      //   this.issueEnabled = true;
      // }
      // else 
      // this.issueEnabled = false;
    }

    issueClicked(){
      console.log("issue clicked", this.selectedRow);

      this.issue.bookId= this.selectedRow.bookId;
      this.issue.bookName = this.selectedRow.bookName;

    }
     
}

