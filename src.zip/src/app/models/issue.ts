export class IssueModel {
    bookId: Number;
    bookName: String;
    memberId: Number;
    memberName: String;
    constructor(){
        
    }
}